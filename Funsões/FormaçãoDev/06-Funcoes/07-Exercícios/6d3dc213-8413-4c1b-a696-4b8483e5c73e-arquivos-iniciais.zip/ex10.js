//Calcular os dígitos validadores de um CPF

//Parte 1 - gerar um array os 9 primeiros números de forma aleatória

function digitosAleatorios(){

}

function primeiroDigito(arr){
}

function segundoDigito(arr){

}

const cpfAleatorio = digitosAleatorios();
const cpfPrimeiraVerificacao = primeiroDigito(cpfAleatorio);
const cpfSegundaVerificacao = segundoDigito(cpfPrimeiraVerificacao)
console.log(cpfSegundaVerificacao)