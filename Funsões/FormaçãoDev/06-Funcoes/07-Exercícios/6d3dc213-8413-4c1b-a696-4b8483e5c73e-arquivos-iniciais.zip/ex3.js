/* Crie uma função que recebe um objeto como parâmetro e retorna um segundo objeto com as chaves e valores do primeiro objeto invertidas*/
function trocaChaveEValor(objeto){
}

const objeto = {nome:"Maria", idade:"45", id:"8745"}

const objetoInvertido = trocaChaveEValor(objeto)

console.log(objeto)
console.log(objetoInvertido)